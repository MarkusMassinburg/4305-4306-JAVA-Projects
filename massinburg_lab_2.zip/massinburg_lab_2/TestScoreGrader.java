import java.util.Scanner;

public class TestScoreGrader {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double[] testScores = new double[5];

        // Input test scores
        for (int i = 0; i < 5; i++) {
            System.out.print("Enter test score " + (i + 1) + ": ");
            testScores[i] = input.nextDouble();
        }

        // Calculate average
        double average = calcAverage(testScores);

        // Display letter grades and average
        System.out.println("\nTest Scores and Letter Grades:");
        for (int i = 0; i < 5; i++) {
            char grade = determineGrade(testScores[i]);
            System.out.println("Test " + (i + 1) + ": " + testScores[i] + " - Grade: " + grade);
        }
        System.out.println("\nAverage Test Score: " + average);
    }

    public static double calcAverage(double[] scores) {
        double sum = 0;
        for (double score : scores) {
            sum += score;
        }
        return sum / scores.length;
    }

    public static char determineGrade(double score) {
        if (score >= 90) {
            return 'A';
        } else if (score >= 80) {
            return 'B';
        } else if (score >= 70) {
            return 'C';
        } else if (score >= 60) {
            return 'D';
        } else {
            return 'F';
        }
    }
}

public class TemperatureConverter {
    public static void main(String[] args) {
    System.out.println("Fahrenheit  |  Celsius");
    System.out.println("----------------------");

    for (int fahrenheit = 0; fahrenheit <= 20; fahrenheit++) {
        double celsius = convertToFahrenheitToCelsius(fahrenheit);
        System.out.printf("%-11d | %.2f%n", fahrenheit, celsius);
    }
}

    public static double convertToFahrenheitToCelsius(int fahrenheit) {
        return (fahrenheit - 32) * 5.0 / 9.0;
    }
}


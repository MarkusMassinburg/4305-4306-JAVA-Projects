import java.util.Scanner;

public class PresentValueCalculator {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter the future value (F): ");
        double futureValue = input.nextDouble();

        System.out.print("Enter the annual interest rate (r): ");
        double annualInterestRate = input.nextDouble();

        System.out.print("Enter the number of years (n): ");
        int numberOfYears = input.nextInt();

        // Calculate the present value
        double presentValue = presentValue(futureValue, annualInterestRate, numberOfYears);

        System.out.println("You need to deposit $" + presentValue + " today.");
    }

    public static double presentValue(double futureValue, double annualInterestRate, int numberOfYears) {
        // Calculate the present value using the formula
        double presentValue = futureValue / Math.pow(1 + annualInterestRate, numberOfYears);
        return presentValue;
    }
}

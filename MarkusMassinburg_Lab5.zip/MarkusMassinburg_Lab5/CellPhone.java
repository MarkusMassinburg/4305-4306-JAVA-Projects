public class CellPhone {
   private String model;
   private String manufacturer;
   private double retailPrice;

   public CellPhone(String m, String man, double price) throws InvalidModelException, InvalidManufacturerException, InvalidRetailPriceException {
      setModel(m);
      setManufacturer(man);
      setRetailPrice(price);
   }

   public CellPhone() throws InvalidModelException, InvalidRetailPriceException, InvalidManufacturerException {
      this("", "", 0.0);
   }

   public void setModel(String m) throws InvalidModelException {
      if (m.isEmpty()) {
         throw new InvalidModelException("Model cannot be empty");
      }
      model = m;
   }

   public void setManufacturer(String man) throws InvalidManufacturerException {
      if (man.isEmpty()) {
         throw new InvalidManufacturerException("Manufacturer cannot be empty");
      }
      manufacturer = man;
   }

   public void setRetailPrice(double price) throws InvalidRetailPriceException {
      if (price < 0 || price > 1500) {
         throw new InvalidRetailPriceException("Invalid retail price");
      }
      retailPrice = price;
   }

   public String getModel() {
      return model;
   }

   public String getManufacturer() {
      return manufacturer;
   }

   public double getRetailPrice() {
      return retailPrice;
   }

   @Override
   public String toString() {
      return String.format("Model: %-20sManufacturer: %-20sretail price: %10.2f%n", getModel(), getManufacturer(),
              getRetailPrice());
   }
}

public class InvalidRetailPriceException extends Exception{
    public InvalidRetailPriceException(String message){
        super(message);
    }
}

public class InvalidManufacturerException extends Exception{
    public InvalidManufacturerException(String message)
    {
        super(message);
    }
}

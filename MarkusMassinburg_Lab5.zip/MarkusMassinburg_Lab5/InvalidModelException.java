public class InvalidModelException extends Exception{
    public InvalidModelException(String message){
        super(message);
    }
}

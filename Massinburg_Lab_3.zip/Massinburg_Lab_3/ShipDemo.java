import java.util.ArrayList;

public class ShipDemo {

    public static void main(String[] args) {

        // Use array
        Ship[] ships = new Ship[3];

        ships[0] = new CruiseShip("Pacific Princess", "1975", 500);
        ships[1] = new CargoShip("Emma Maersk", "2006", 151627);
        ships[2] = new CruiseShip("Symphony of the Seas","2018", 6700);

        for(Ship ship : ships) {
            ship.display();
        }

        // Use ArrayList
        ArrayList<Ship> shipList = new ArrayList();
        shipList.add(new CruiseShip("Queen Mary 2", "2004", 3100));
        shipList.add(new CargoShip("MSC Oscar", "2015", 19224));

        for(Ship ship : shipList) {
            ship.display();
        }
    }
}

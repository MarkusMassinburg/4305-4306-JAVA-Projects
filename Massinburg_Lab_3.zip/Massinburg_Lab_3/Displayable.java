
    public interface Displayable {
        public void display();
    }



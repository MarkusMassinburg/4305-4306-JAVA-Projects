public class CruiseShip extends Ship implements Displayable {

    private int maxPassengers;

    public CruiseShip(String name, String yearBuilt, int maxPassengers) {
        super(name, yearBuilt);
        this.maxPassengers = maxPassengers;
    }

    public int getMaxPassengers() {
        return maxPassengers;
    }

    public void setMaxPassengers(int maxPassengers) {
        this.maxPassengers = maxPassengers;
    }

    public String toString() {
        return getName() + " (" + maxPassengers + ")";
    }

    public void display() {
        System.out.println(toString());
    }
}

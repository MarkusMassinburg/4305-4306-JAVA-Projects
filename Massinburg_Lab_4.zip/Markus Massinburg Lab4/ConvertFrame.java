import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Objects;
import javax.swing.*;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class ConvertFrame extends JFrame
{
    private JPanel fromJPanel;
    private JPanel toJPanel;
    private JPanel iconFromPanel;
    private JPanel iconToPanel;
    private JPanel bottomButtons;
    private JLabel label1;
    private JLabel label2;
    private JLabel label3;
    private JLabel label4;
    private JTextField currJTextField1;
    private JTextField currJTextField2;
    private ButtonGroup fromButtonGroup;
    private ButtonGroup toButtonGroup;

    private ButtonGroup toBottomButtons;
    private JRadioButton usdToJRadioButton;
    private JRadioButton mxnpesoToJRadioButton;
    private JRadioButton euroToJRadioButton;
    private JRadioButton usdFromJRadioButton;
    private JRadioButton mxnpesoFromJRadioButton;
    private JRadioButton euroFromJRadioButton;
    private JButton convertButton;
    private JButton clearButton;
    private JButton exitButton;




    protected ConvertFrame()
    {
        super("Currency Conversion");
        //menu starts here
        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic('F');
        JMenuItem about_menu = new JMenuItem("About");
        about_menu.setMnemonic('A');
        JMenuItem clear_menu = new JMenuItem("Clear");
        clear_menu.setMnemonic('N');
        fileMenu.add(about_menu);
        JMenuItem convertItem = new JMenuItem("Convert");
        convertItem.setMnemonic('C');
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.setMnemonic('x');
        fileMenu.add(convertItem);
        fileMenu.add(clear_menu);
        MyEventHandler covertItemHandler = new MyEventHandler();
        convertItem.addActionListener(covertItemHandler);
        about_menu.addActionListener(
                new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent event)
                    {
                        JOptionPane.showMessageDialog(ConvertFrame.this,"Currency Conversion Program\nusing menus and buttons\nsource: https://www.oanda.com/currency-converter/", "About", JOptionPane.PLAIN_MESSAGE);
                    }
                }
        );

        fileMenu.add(exitItem);
        exitItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        JMenuBar bar = new JMenuBar();
        bar.add(fileMenu);
        setJMenuBar(bar);


        usdFromJRadioButton =
                new JRadioButton("USD", true);
        mxnpesoFromJRadioButton = new JRadioButton("Peso", false);
        euroFromJRadioButton = new JRadioButton("Euro",   false);
        fromButtonGroup = new ButtonGroup();
        fromButtonGroup.add(usdFromJRadioButton);
        fromButtonGroup.add(mxnpesoFromJRadioButton);
        fromButtonGroup.add(euroFromJRadioButton);

        convertButton = new JButton("Convert");
        clearButton = new JButton("Clear");
        exitButton = new JButton("Exit");

        usdToJRadioButton =
                new JRadioButton("USD", false);
        mxnpesoToJRadioButton = new JRadioButton("peso", true);
        euroToJRadioButton = new JRadioButton("euro", false);
        toButtonGroup = new ButtonGroup();
        toButtonGroup.add(usdToJRadioButton);
        toButtonGroup.add(mxnpesoToJRadioButton);
        toButtonGroup.add(euroToJRadioButton);



        fromJPanel = new JPanel();
        fromJPanel.setLayout(new GridLayout(1, 3));
        fromJPanel.add(usdFromJRadioButton);
        fromJPanel.add(mxnpesoFromJRadioButton);
        fromJPanel.add(euroFromJRadioButton);

        toJPanel = new JPanel();
        toJPanel.setLayout(new GridLayout(1, 3));
        toJPanel.add(usdToJRadioButton);
        toJPanel.add(mxnpesoToJRadioButton);
        toJPanel.add(euroToJRadioButton);

        bottomButtons = new JPanel();
        bottomButtons.setLayout(new GridLayout(1, 3));
        bottomButtons.add(convertButton);
        bottomButtons.add(clearButton);
        bottomButtons.add(exitButton);



        ImageIcon usd_Icon = new ImageIcon(getClass().getResource("dollar.jpg"));
        ImageIcon peso_Icon = new ImageIcon(getClass().getResource("peso.jpg"));
        ImageIcon euro_Icon = new ImageIcon(getClass().getResource("euro.jpg"));

        iconToPanel = new JPanel();
        iconToPanel.setLayout(new GridLayout(1, 3));
        JLabel usdIcon = new JLabel(usd_Icon);
        JLabel pesoIcon = new JLabel(peso_Icon);
        JLabel euroIcon = new JLabel(euro_Icon);
        iconToPanel.add(usdIcon);
        iconToPanel.add(pesoIcon);
        iconToPanel.add(euroIcon);

        iconFromPanel = new JPanel();
        iconFromPanel.setLayout(new GridLayout(1, 3));
        JLabel usdIcon2 = new JLabel(usd_Icon);
        JLabel pesoIcon2 = new JLabel(peso_Icon);
        JLabel euroIcon2 = new JLabel(euro_Icon);
        iconFromPanel.add(usdIcon2);
        iconFromPanel.add(pesoIcon2);
        iconFromPanel.add(euroIcon2);









        label1 = new JLabel("Convert from:");
        label2 = new JLabel("Convert to:");
        label3 = new JLabel("Enter Amount: ");
        label4 = new JLabel("Currency Conversion is: ");

        currJTextField1 = new JTextField(10);
        currJTextField1.setText("0");



        MyEventHandler handler = new MyEventHandler();
        currJTextField1.addActionListener(handler);

        currJTextField2 = new JTextField(10);
        currJTextField2.setEditable(false);



        MyEventHandler handlerButton = new MyEventHandler();
        currJTextField1.addActionListener(handlerButton);
        convertButton.addActionListener(handlerButton);
        clearButton.addActionListener(handlerButton);
        clear_menu.addActionListener(handlerButton);
        convertItem.addActionListener(handlerButton);
        exitItem.addActionListener(handlerButton);
        exitButton.addActionListener(handlerButton);



        setLayout(new GridLayout(11, 1));
        add(label1);
        add(iconFromPanel);
        add(fromJPanel);
        add(label3);
        add(currJTextField1);
        add(label2);
        add(iconToPanel);
        add(toJPanel);
        add(label4);
        add(currJTextField2);
        add(bottomButtons);
    }


    private class MyEventHandler implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent event) {
            double convertCurr =0 , currency;
            String result = ""; // for Pop up window

            currency = Double.parseDouble(currJTextField1.getText());

            if(currJTextField1.equals("0.0"))
            {
                System.out.println("ZERO");
                currency = 0;
            }
            else
            {
                convertCurr = Integer.parseInt(currJTextField1.getText());
            }

            if(event.getActionCommand().equals("Clear"))
            {
                currJTextField1.setText("0.0");
                currJTextField2.setText("");


            }
            else if(event.getActionCommand().equals("Exit"))
            {
                JFrame frame = new JFrame();
                int number = JOptionPane.showConfirmDialog(frame, "Are you sure you want to exit?", "Exit Confirmation : ", JOptionPane.YES_NO_OPTION);
                if(number == JOptionPane.YES_OPTION)
                {
                    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    System.exit(0);
                }
                else
                {
                    frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
                }
            }
            // USD to Peso
            else if (usdFromJRadioButton.isSelected() &&
                    mxnpesoToJRadioButton.isSelected())
            {
                convertCurr = (double) (currency * 18.0246);
                currJTextField2.setText(
                        String.valueOf(convertCurr));
                result = "US Dollar to Peso";
            }
            // USD to Euro
            else if (usdFromJRadioButton.isSelected() &&
                    euroToJRadioButton.isSelected())
            {
                convertCurr= (double)
                        (currency * .91274);
                currJTextField2.setText(
                        String.valueOf(convertCurr));
                result = "US Dollar to Euro";
            }
            // Peso to USD
            else if (mxnpesoFromJRadioButton.isSelected() &&
                    usdToJRadioButton.isSelected())
            {
                convertCurr = (double) (currency * .05546);
                currJTextField2.setText(
                        String.valueOf(convertCurr));
                result = "Peso to US Dollar";
            }
            // Peso to Euro
            else if (mxnpesoFromJRadioButton.isSelected() &&
                    euroToJRadioButton.isSelected())
            {
                convertCurr = (double) (currency * .05062);
                currJTextField2.setText(
                        String.valueOf(convertCurr));
                result = "Peso to Euro";
            }
            // Euro to Peso
            else if (euroFromJRadioButton.isSelected() &&
                    mxnpesoToJRadioButton.isSelected())
            {
                convertCurr = (double) (currency * 19.7448);
                currJTextField2.setText(
                        String.valueOf(convertCurr));
                result = "Euro to Peso";
            }
            // Euro to USD
            else if (euroFromJRadioButton.isSelected() &&
                    usdToJRadioButton.isSelected())
            {
                convertCurr =
                        (double) (currency * 1.09544);
                currJTextField2.setText(
                        String.valueOf(convertCurr));
                result = "Euro to US Dollar";
            }
            else {
                currJTextField2.setText(String.valueOf(currency));
                result = "No conversion selected";
            }

            result += "\n"+ currency + "  to \t\t  " + convertCurr + "";

            if(!event.getActionCommand().equals("Clear"))
            {
                JOptionPane.showMessageDialog(ConvertFrame.this,result,"Result",JOptionPane.INFORMATION_MESSAGE);
            }
            else if(!event.getActionCommand().equals("Exit"))
            {
                JOptionPane.showMessageDialog(ConvertFrame.this,result,"Result",JOptionPane.INFORMATION_MESSAGE);
            }        }
    }
}

public class Employee {
    private String name;
    private int idNumber;
    private String department;
    private String position;
    private double salary;

    public Employee(String name, int idNumber, String department, String position, double salary){
        this.name = name;
        this.idNumber = idNumber;
        this.department = department;
        this.position = position;
        this.salary = (salary >= 0 && salary <= 90000) ? salary : 0.0;
    }

    public Employee(String name, int idNumber) {
        this(name, idNumber, "", "", 0.0);
    }

    public Employee() {
        this("", 0, "", "", 0.0);
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setIdNumber(int idNumber) {
        this.idNumber = idNumber;
    }

    public int getIdNumber() {
        return idNumber;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getPosition() {
        return position;
    }

    public void setSalary(double salary) {
        if (salary >= 0 && salary <= 90000) {
            this.salary = salary;
        } else {
            this.salary = 0.0;
        }
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString(){
        return "Name: " + name +
                ", ID Number: " + idNumber +
                ", Department: " + department +
                ", Position: " + position +
                ", Salary: " + salary;
    }
}